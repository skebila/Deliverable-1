package unogameproject;

import java.util.ArrayList;

public class UnoPlayer {

    /**
     *  Representation of a player to use inside UnoGame class as an ArrayList of <UnoPlayer>
     *      Every player has a hand
     *      - At the beginning of the turn draws 7 cards by default
     *      - Wins if the hand equals 0
     *      - May exit the game if its his turn:
     *          -In this case cards get returned to the deck
     *
     */

    //--------------------------FIELDS--------------------------------//

    // PLAYER NUMBER
    private int playerNumber;

    // PLAYER HAND
    public ArrayList<UnoCard> hand;

    //-----------------------CONSTRUCTORS-----------------------------//

    // CONSTRUCTOR
    public UnoPlayer(int playerNumber) {
        this.playerNumber = playerNumber;
        hand = new ArrayList<>();
    }

    //-------------------------METHODS--------------------------------//

    public int getPlayerNumber() {
        return playerNumber;
    }

    public ArrayList<UnoCard> getHand() {
        return hand;
    }

    public boolean hasCards() {
        if(hand.size() > 0) {
            return true;
        }
        return false;
    }

    //PLAY CARD
    public boolean playCard(int cardNumberToPlay, UnoPile pileToPlaceCard) {
        if(cardNumberToPlay < 0 || cardNumberToPlay > hand.size()) {
            return false;
        } else {
            if(pileToPlaceCard.placeCard(hand.get(cardNumberToPlay -1))) {
                hand.remove(cardNumberToPlay -1);
                return true;
            }
            return false;
        }
    }

    // DRAW CARDS
    public boolean drawCards(UnoDeck deckToDrawFrom, int numberOfCardsToDraw) {
        if(deckToDrawFrom.hasMoreCards(numberOfCardsToDraw)) {
            for(int i = 0; i < numberOfCardsToDraw; i++) {
                hand.add(UnoDeck.drawCard());
            }
            return true; // Zawad has added to test this method
        }
        return false;
    }

    //------------------STRING_REPRESENTATION-----------------------//

    // PAINT PLAYER'S HAND TO CONSOLE
    //changed the code to return to test
    public String paintPlayerHand() {
        if(hand == null || hand.size() == 0) {
            String s ="PLAYER " + playerNumber + " HAND IS NULL OR EMPTY";
            System.out.println(s);
            return s;
        } else {
            StringBuilder sb = new StringBuilder();

            sb.append("---PLAYER---" + playerNumber + "------MAKE------YOUR------MOVE----------------------------------------");
            sb.append("\n");
            sb.append("\n");

            for(int i = 0; i < hand.size(); i++) {
                sb.append("   CARD_" + (i+1) + "   ");
            }
            sb.append("\n");
            for(int i = 0; i < hand.size(); i++) {
                sb.append(" ---------- ");
            }
            sb.append("\n");
            for(int i = 0; i < hand.size(); i++) {
                sb.append("| -" + hand.get(i).getColor() + "- |");
            }
            sb.append("\n");
            for(int i = 0; i < hand.size(); i++) {
                sb.append("|          |");
            }
            sb.append("\n");
            for(int i = 0; i < hand.size(); i++) {
                sb.append("| -" + hand.get(i).getValue() + "- |");
            }
            sb.append("\n");
            for(int i = 0; i < hand.size(); i++) {
                sb.append(" ---------- ");
            }
            String s = sb.toString();
            System.out.println(s);
            return s;
        }
    }

}